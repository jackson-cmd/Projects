// cmd.c: functions related the cmd_t struct abstracting a
// command. Most functions maninpulate cmd_t structs.
#include "commando.h"
#define SIZE 128//limit the number of bytes read so that this buffer is not overflowed

cmd_t *cmd_new(char *argv[]){
  cmd_t *cmd=(cmd_t *)malloc(sizeof(cmd_t));//use malloc() to allocate a hunk of memory that is sizeof(cmd_t)
  for(int i=0;i<ARG_MAX+1;i++){
    if(argv[i]!=NULL)//Ensures that cmd->argv[] is ended with NULL
      cmd->argv[i]=strdup(argv[i]);//strdup() function makes copying strings relatively easy.
    else{
      cmd->argv[i]=NULL;
      break;
    }
  }
  strcpy(cmd->name,cmd->argv[0]);//cmd->name field is always identical to cmd->argv[0].
  snprintf(cmd->str_status,5,"%s","INIT");//it "prints" like printf() but into a character array rather than onto the screen.
  //Initializes the remaining
  // fields to obvious default values such as -1s, and NULLs.
  cmd->pid=-1;
  cmd->out_pipe[0]=-1;
  cmd->out_pipe[1]=-1;
  cmd->finished=0;//Sets finished to 0 (not finished yet)
  cmd->status=-1;
  cmd->output=NULL;
  cmd->output_size=-1;
  return cmd;
}
// Allocates a new cmd_t with the given argv[] array. Makes string
// copies of each of the strings contained within argv[] using
// strdup() as they likely come from a source that will be
// altered. Ensures that cmd->argv[] is ended with NULL. Sets the name
// field to be the argv[0]. Sets finished to 0 (not finished yet). Set
// str_status to be "INIT" using snprintf(). Initializes the remaining
// fields to obvious default values such as -1s, and NULLs.


void cmd_free(cmd_t *cmd){
  for(int i=0;i<ARG_MAX;i++){
    if(cmd->argv[i]!=NULL)//Deallocates the strings in the argv[] array
      free(cmd->argv[i]);
    else{
        break;
    }
  }
  if(cmd->output!=NULL)//deallocats the output buffer if it is not NULL
    free(cmd->output);
  free(cmd);//Finally, deallocates cmd itself.

}
// Deallocates a cmd structure. Deallocates the strings in the argv[]
// array. Also deallocats the output buffer if it is not
// NULL. Finally, deallocates cmd itself.


void cmd_start(cmd_t *cmd){
  snprintf(cmd->str_status,4,"%s","RUN");//Changes the str_status field to "RUN" using snprintf()
  if(pipe(cmd->out_pipe)<0){exit(1);}
  pid_t child_pid =fork();//Forks a process
  if(child_pid == 0){//child process
    close(cmd->out_pipe[PREAD]);//closes the read end of the pipe
    dup2(cmd->out_pipe[PWRITE],STDOUT_FILENO);
    //use dup2() to alter its standard output to write instead to the write to cmd->out_pipe[PWRITE]
    execvp(cmd->name,cmd->argv);//child should call execvp() with the name of the command and argv[] array stored in the passed cmd
  }
  else{//parent process
    close(cmd->out_pipe[PWRITE]);// the parent closes the write end of the pipe
    cmd->pid=child_pid;//the pid field is set to the child PID
  }
}
// Forks a process and starts executes command in cmd in the process.
// Changes the str_status field to "RUN" using snprintf().  Creates a
// pipe for out_pipe to capture standard output.  In the parent
// process, ensures that the pid field is set to the child PID. In the
// child process, directs standard output to the pipe using the dup2()
// command. For both parent and child, ensures that unused file
// descriptors for the pipe are closed (write in the parent, read in
// the child).

void cmd_update_state(cmd_t *cmd, int block){
  if(cmd->finished==1){}
  //cmd_t has a finished field and when 1, the command has already finished so no further state changes can occur
  else{
    waitpid(cmd->pid,&cmd->status,block);//waitpid() to check a child.
    if(WIFEXITED(cmd->status)){//If the WIFEXITED(status) evaluate to nonzero, the child process has exited
      cmd->status=WEXITSTATUS(cmd->status);// WEXITSTATUS(status) which should be assigned to the cmd->status field.
      snprintf(cmd->str_status,8,"EXIT(%d)",cmd->status);//Change cmd->str_status to EXIT(num) when the process finishes.
      cmd->finished=1;//Set its finish field to 1
      cmd_fetch_output(cmd);//Call cmd_fetch_output() to read the contents of the pipe into the command's output buffer.
      printf("@!!! %s[#%d]: EXIT(%d)\n",cmd->name,cmd->pid,cmd->status );
    }
  }
}
// If the finished flag is 1, does nothing. Otherwise, updates the
// state of cmd.  Uses waitpid() and the pid field of command to wait
// selectively for the given process. Passes block (one of DOBLOCK or
// NOBLOCK) to waitpid() to cause either non-blocking or blocking
// waits.  Uses the macro WIFEXITED to check the returned status for
// whether the command has exited. If so, sets the finished field to 1
// and sets the cmd->status field to the exit status of the cmd using
// the WEXITSTATUS macro. Calls cmd_fetch_output() to fill up the
// output buffer for later printing.
//
// When a command finishes (the first time), prints a status update
// message of the form
//
// @!!! ls[#17331]: EXIT(0)
//
// which includes the command name, PID, and exit status.

char *read_all(int fd, int *nread){
  int buf_size=BUFSIZE;//buf_size is buffer size.
  char *buf=(char *)malloc(buf_size);//malloc() an initial buffer size such as 1024 bytes
  int total=0, red=0;//alr is the byte already read,red is each time read bytes
  while(1){
    if(total+SIZE>buf_size-1){//adjusting the buffer sizes in allocation a little (add 1)
      buf_size*=2;
      buf=(char *)realloc(buf,buf_size);//use realloc() to double the current size of the buffer.
    }
    red=read(fd,buf+total,SIZE);
    total+=red;
    if(red<SIZE)//When read() calls no longer give more bytes (return value of 0 or less)
      break;//reading is finished
  }
  buf[total]='\0';
  *nread=total;//Set the integer nread to be the total bytes read then return the allocated buffer of data.
  return buf;
}
// Reads all input from the open file descriptor fd. Stores the
// results in a dynamically allocated buffer which may need to grow as
// more data is read.  Uses an efficient growth scheme such as
// doubling the size of the buffer when additional space is
// needed. Uses realloc() for resizing.  When no data is left in fd,
// sets the integer pointed to by nread to the number of bytes read
// and return a pointer to the allocated buffer. Ensures the return
// string is null-terminated. Does not call close() on the fd as this
// is done elsewhere.

void cmd_fetch_output(cmd_t *cmd){
  if(cmd->finished==0){//check if the cmd_t is finished and if not,
    printf("%s[#%d] not finished yet\n",cmd->name,cmd->pid);
  }
  cmd->output=read_all(cmd->out_pipe[PREAD],&cmd->output_size);//use read_all() with output_pipe to extract bytes from the pipe
  close(cmd->out_pipe[PREAD]);//Make sure to close the pipe that was read from.

}
// If cmd->finished is zero, prints an error message with the format
//
// ls[#12341] not finished yet
//
// Otherwise retrieves output from the cmd->out_pipe and fills
// cmd->output setting cmd->output_size to number of bytes in
// output. Makes use of read_all() to efficiently capture
// output. Closes the pipe associated with the command after reading
// all input.

void cmd_print_output(cmd_t *cmd){
  if(cmd->output ==NULL)
    printf("%s[#%d] : output not ready\n",cmd->name,cmd->pid);
  else
    write(STDOUT_FILENO,cmd->output,cmd->output_size);
}
// Prints the output of the cmd contained in the output field if it is
// non-null. Prints the error message
//
// ls[#17251] : output not ready
//
// if output is NULL. The message includes the command name and PID.
