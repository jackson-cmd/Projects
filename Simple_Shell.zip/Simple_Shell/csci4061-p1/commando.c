#include "commando.h"

int main(int argc, char **argv){
  setvbuf(stdout, NULL, _IONBF, 0); // Turn off output buffering
  char *line="----------------------------------------\n";
  char input[MAX_LINE];
  char **ninput=malloc(ARG_MAX*NAME_MAX);//WITH spaces
  static int echoing;
  int nums;//nums is number of tokens that are found.;
  cmdcol_t *cmdcol=(cmdcol_t *)malloc(MAX_CMDS*sizeof(cmd_t));
  cmdcol->size=0;
  if (argc > 1 && !strcmp(argv[1], "--echo")) {//The 1th argument of argv[] is the string --echo
    echoing = 1;
  }
  else if (getenv("COMMANDO_ECHO") != NULL) {//
    echoing = 1;//The environment variable COMMANDO_ECHO is set to anything
  }
  while(1){
    printf("@> ");
    if(!fgets(input,MAX_LINE,stdin)){//Use a call to fgets() to read a whole line of text from the user.
        printf("\nEnd of input\n");// If no input is remains, print End of input and break out of the loop.
	      break;
    }
    parse_into_tokens(input,ninput,&nums);//Use a call to parse_into_tokens()
    if(echoing){//Echo (print) given input if echoing is enabled
      for(int i=0;i<nums;i++){
        printf("%s ",ninput[i]);
      }
      printf("\n");
    }
    if(ninput[0]==NULL){}//use just hit enter
    else if(strncmp("help",ninput[0],4)==0){
      printf("%-18s\n", "COMMANDO COMMANDS");
      printf("%-18s : %s\n", "help", "show this message");
      printf("%-18s : %s\n", "exit", "exit the program");
      printf("%-18s : %s\n", "list","list all jobs that have been started giving information on each");
      printf("%-18s : %s\n", "pause nanos secs","pause for the given number of nanseconds and seconds");
      printf("%-18s : %s\n", "output-for int","print the output for given job number");
      printf("%-18s : %s\n", "output-all", "print output for all jobs");
      printf("%-18s : %s\n", "wait-for int","wait until the given job number finishes");
      printf("%-18s : %s\n", "wait-all", "wait for all jobs to finish");
      printf("%-18s : %s\n", "command arg1 ...", "non-built-in is run as a job");
    }
    else if(strncmp("exit",ninput[0],4)==0){
      break;
    }
    else if(strncmp("list",ninput[0],4)==0){
      cmdcol_print(cmdcol);
    }
    else if(strncmp("pause",ninput[0],5)==0){
      pause_for(atoi(ninput[1]),atoi(ninput[2]));// Sleep the running program for the given number of nanoseconds and seconds.
      cmdcol_update_state(cmdcol,NOBLOCK);
    }
    else if(strncmp("output-for",ninput[0],10)==0){
      int jobindex=atoi(ninput[1]);//the second args
      cmd_t *cmd=cmdcol->cmd[jobindex];
      printf("@<<< Output for %s[#%d] (%d bytes):\n",cmd->name,cmd->pid,cmd->output_size);
      printf("%s", line);
      cmd_print_output(cmd);
      printf("%s", line);
    }
    else if(strncmp("output-all",ninput[0],10)==0){
      for(int i=0;i<cmdcol->size;i++){
        printf("@<<< Output for %s[#%d] (%d bytes):\n",cmdcol->cmd[i]->name,cmdcol->cmd[i]->pid,cmdcol->cmd[i]->output_size);
        printf("%s", line);
        cmd_print_output(cmdcol->cmd[i]);
        printf("%s", line);
      }
    }
    else if(strncmp("wait-for",ninput[0],8)==0){
      int jobindex=atoi(ninput[1]);//the second args
      if(jobindex<cmdcol->size){
      cmd_update_state(cmdcol->cmd[jobindex],DOBLOCK);
      }
    }
    else if(strncmp("wait-all",ninput[0],8)==0){
	for(int i=0;i<cmdcol->size;i++){
   	    cmd_update_state(cmdcol->cmd[i],DOBLOCK);
	}
    }
    else{//If no built-ins match, create a new cmd_t instance where the tokens are the argv[] for it and start it running.
      cmd_t *cmd=cmd_new(ninput);
      cmd_start(cmd);
      cmdcol_add(cmdcol,cmd);

    }
    cmdcol_update_state(cmdcol,NOBLOCK);

  }
  free(ninput);
  cmdcol_freeall(cmdcol);
  free(cmdcol);
  return 0;
//   Print the prompt @>
// Use a call to fgets() to read a whole line of text from the user. The #define MAX_LINE limits the length of what will be read. If no input is remains, print End of input and break out of the loop.
// Echo (print) given input if echoing is enabled.
// Use a call to parse_into_tokens() from util.c to break the line up by spaces. If there are no tokens, jump to the end of the loop (the use just hit enter).
// Examine the 0th token for built-ins like help, list, and so forth. Use strncmp() to determine if any match and make appropriate calls. This will be a long if/else chain of statements.
// If no built-ins match, create a new cmd_t instance where the tokens are the argv[] for it and start it running.
// At the end of each loop, update the state of all child processes via a call to cmdcol_update_state().

}
