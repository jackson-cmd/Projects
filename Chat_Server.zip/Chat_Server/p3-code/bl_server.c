#include "blather.h"
// REPEAT:
//   check all sources
//   handle a join request if one is ready
//   for each client{
//     if the client is ready handle data from it
//   }
// }
int signalled = 0;                                               // indicates if the server should shut down at next opportunity
void handle_signals(int sig_num){
  signalled = 1;

}

int main(int argc, char *argv[]) {
    if(argc<2){
        perror("NOt enough parameter");//error check
        exit(1);
    }
    server_t server={};
  //setvbuf(stdout, NULL, _IONBF, 0);
  struct sigaction my_sa = {
    .sa_handler = handle_signals,                             // run function handle_signals
      .sa_flags=SA_RESTART,
  };
  sigaction(SIGTERM, &my_sa, NULL);                              // handle SIGTERM and
  sigaction(SIGINT,  &my_sa, NULL);                              // SIGINT by shutting down
  server_start(&server,argv[1],DEFAULT_PERMS);//start server
  while(!signalled){//Not shutdown
   // if(getenv("BL_ADVANCED")){
   // DO_ADVANCED=1;
   // }                                             // loop while no signal is received
    server_check_sources(&server);//check if source ready
    if(server.join_ready==1){//if join ready
      server_handle_join(&server);
    }
    for(int i=0;i<server.n_clients;i++){//if data ready
      if(server_get_client(&server,i)->data_ready){
        server_handle_client(&server,i);
    }
  }
  }   
  server_shutdown(&server);//shutdown server when signaled
  return 0;
}
