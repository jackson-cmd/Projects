#include "blather.h"
client_t *server_get_client(server_t *server, int idx){
  if(idx>server->n_clients){//index beyond n_clients
    perror("Cause crash.\n");
      return NULL;
  }
  return &server->client[idx];
}
// Gets a pointer to the client_t struct at the given index. If the
// index is beyond n_clients, the behavior of the function is
// unspecified and may cause a program crash.

void server_start(server_t *server, char *server_name, int perms){
  log_printf("BEGIN: server_start()\n");              // at beginning of function
    dbg_printf("At the top of main loop\n");
  char fifo[strlen(server_name)+6];//name of fifo
  sprintf(server->server_name,"%s",server_name);//not include the \0
  snprintf(fifo,strlen(server_name)+6,"%s.fifo",server_name);//include the \0
  remove(fifo);                                       // remove old requests FIFO

if(mkfifo(fifo, perms)<0){
    perror("Cant make fifo\n");//Erorr check
    }                    // create requests FIFO for client requests
  server->join_fd= open(fifo, O_RDWR,perms);               // open FIFO read/write to avoid blocking
    
    check_fail(server->join_fd==-1,1,"Can't opening fifo\n");//check error
//  //ADVANCED Put advance in comment, so don't affect the general test case
//  char log[strlen(server_name)+5];
//  char sem_name[strlen(server_name)+5];
//  who_t who;//initial who_t
//  snprintf(sem_name, strlen(server_name)+5,"%s.sem",server_name);
//  snprintf(log, strlen(server_name)+5,"%s.log",server_name);
//  int fd=open(log, O_CREAT | O_WRONLY |O_APPEND,perms);
//  sem_t *sem=sem_open(sem_name, O_CREAT,perms);
//  sem_init(sem,0,1);
//  sem_wait(sem);
//  lseek(fd, 0, SEEK_END);
//  server->log_fd=fd;
//  write(fd,&who,sizeof(who));//?
//  sem_post(sem);
//
   log_printf("END: server_start()\n");                // at end of function

}
// Initializes and starts the server with the given name. A join fifo
// called "server_name.fifo" should be created. Removes any existing
// file of that name prior to creation. Opens the FIFO and stores its
// file descriptor in join_fd.
//
// ADVANCED: create the log file "server_name.log" and write the
// initial empty who_t contents to its beginning. Ensure that the
// log_fd is position for appending to the end of the file. Create the
// POSIX semaphore "/server_name.sem" and initialize it to 1 to
// control access to the who_t portion of the log.
//
// LOG Messages:
// log_printf("BEGIN: server_start()\n");              // at beginning of function
// log_printf("END: server_start()\n");                // at end of function

void server_shutdown(server_t *server){
  log_printf("BEGIN: server_shutdown()\n");           // at beginning of function
    dbg_printf("Shutdown server\n");
  close(server->join_fd);//close the fifo
  char fifo[MAXPATH];//name of fifo
  snprintf(fifo,strlen(server->server_name)+6,"%s.fifo",server->server_name);//include the \0
  remove(fifo);                                       // remove old requests FIFO

  mesg_t shutdown;//send message shutdown
   memset(&shutdown,0,sizeof(mesg_t));//initialize
  shutdown.kind=BL_SHUTDOWN;
  server_broadcast(server,&shutdown);
  for(int i=0;i<server->n_clients;i++){
    server_remove_client(server,i);//remove all clients
  }
  //close(server->log_fd);
  //sem_close(server->log_sem);
  log_printf("END: server_shutdown()\n");             // at end of function

}
// Shut down the server. Close the join FIFO and unlink (remove) it so
// that no further clients can join. Send a BL_SHUTDOWN message to all
// clients and proceed to remove all clients in any order.
//
// ADVANCED: Close the log file. Close the log semaphore and unlink
// it.
//
// LOG Messages:
// log_printf("BEGIN: server_shutdown()\n");           // at beginning of function
// log_printf("END: server_shutdown()\n");             // at end of function

int server_add_client(server_t *server, join_t *join){
  log_printf("BEGIN: server_add_client()\n");         // at beginning of function
    dbg_printf("server add client: %s\n",join->name);
  if (server->n_clients == MAXCLIENTS){//no space for clients (n_clients == MAXCLIENTS).
    perror("No space\n");
    exit(1);
  }
  client_t *client=server_get_client(server,server->n_clients);//create a new client

  strncpy(client->name,join->name,MAXNAME);//copy the name and fanme to new client
  strncpy(client->to_client_fname, join->to_client_fname,MAXPATH);
  strncpy(client->to_server_fname, join->to_server_fname,MAXPATH);
  client->data_ready=0;//nitializes the data_ready field
  // for the client to 0
  client->to_client_fd=open(client->to_client_fname, O_WRONLY, DEFAULT_PERMS);
  check_fail(client->to_client_fd==-1,1,"Can't opening fifo\n");//check error
  client->to_server_fd=open(client->to_server_fname, O_RDONLY, DEFAULT_PERMS);
  check_fail(client->to_server_fd==-1,1,"Can't opening fifo\n");//check error
  server->n_clients++;
  log_printf("END: server_add_client()\n");           // at end of function
  return 0;
}
// Adds a client to the server according to the parameter join which
// should have fileds such as name filed in.  The client data is
// copied into the client[] array and file descriptors are opened for
// its to-server and to-client FIFOs. Initializes the data_ready field
// for the client to 0. Returns 0 on success and non-zero if the
// server as no space for clients (n_clients == MAXCLIENTS).
//
// LOG Messages:
// log_printf("BEGIN: server_add_client()\n");         // at beginning of function
// log_printf("END: server_add_client()\n");           // at end of function

int server_remove_client(server_t *server, int idx){
  close(server_get_client(server, idx)->to_client_fd);
  close(server_get_client(server, idx)->to_server_fd);// Close fifos associated with the client and remove
  // them.

  remove(server_get_client(server, idx)->to_client_fname); //Remove the given client likely due to its having departed or
  // disconnected.
  remove(server_get_client(server, idx)->to_server_fname);
    dbg_printf("Server remove %s\n",server->client[idx].name);
  server->n_clients--;//decrease 1
  for(int i=idx;i<server->n_clients;i++){
    server->client[i]=server->client[i+1];//points to the next one
  }
  return 0;
}
// Remove the given client likely due to its having departed or
// disconnected. Close fifos associated with the client and remove
// them.  Shift the remaining clients to lower indices of the client[]
// preserving their order in the array; decreases n_clients.

int server_broadcast(server_t *server, mesg_t *mesg){
    dbg_printf("server_broadcast() to %s clients\n", server->n_clients);
  for(int i=0;i<server->n_clients;i++){
    int bytes=write(server_get_client(server, i)->to_client_fd, mesg,sizeof(mesg_t));
    if(bytes<0){perror("Can't wrtie\n");}
  }
  if(mesg->kind != BL_PING){//advanced feature
    server_log_message(server,mesg);
  }
  return 0;
}
// Send the given message to all clients connected to the server by
// writing it to the file descriptors associated with them.
//
// ADVANCED: Log the broadcast message unless it is a PING which
// should not be written to the log.

void server_check_sources(server_t *server){
  log_printf("BEGIN: server_check_sources()\n");             // at beginning of function
  struct pollfd pfds[server->n_clients+1];
    pfds[0].fd=server->join_fd;
    pfds[0].events=POLLIN;
    for(int i=1;i<=server->n_clients;i++){
      pfds[i].fd=server_get_client(server, i-1)->to_server_fd;
      pfds[i].events=POLLIN;
    }
  log_printf("poll()'ing to check %d input sources\n",server->n_clients+1);  // prior to poll() call
  
  
  int ret=poll(pfds,server->n_clients+1,-1);
    //if( ret < 0 ){
  log_printf("poll() completed with return value %d\n",ret); // after poll() call,complete or signaled
      //perror("poll() failed, possibly signaled");
      //exit(-1);
    //}
    //log_printf("poll() completed with return value %d\n",ret); // after poll() call
    
 if(ret==-1){//signal was caught during poll()
   log_printf("poll() interrupted by a signal\n");            // if poll interrupted by a signal
     log_printf("END: server_check_sources()\n");               // at end of function
     server_shutdown(server);
     exit(1);
 }

  if(pfds[0].revents & POLLIN){//see if there is any join
      server->join_ready = 1;
     log_printf("join_ready = %d\n",server->join_ready);                       // whether join queue has data
  }
  else{
    log_printf("join_ready = %d\n",server->join_ready);                       // whether join queue has data
  }
   for(int i=1;i<=server->n_clients;i++){//see if any client have data ready

      if(pfds[i].revents & POLLIN){
        server_get_client(server, i-1)->data_ready=1;
        log_printf("client %d '%s' data_ready = %d\n",i-1,server_get_client(server, i-1)->name,server_get_client(server, i-1)->data_ready);         // whether client has data ready
      }
    else {
        log_printf("client %d '%s' data_ready = %d\n",i-1,server_get_client(server, i-1)->name,server_get_client(server, i-1)->data_ready);         // whether client has data ready
        
    }

    }
  
  log_printf("END: server_check_sources()\n");               // at end of function
    dbg_printf("Finished checking sources\n");
}
// Checks all sources of data for the server to determine if any are
// ready for reading. Sets the servers join_ready flag and the
// data_ready flags of each of client if data is ready for them.
// Makes use of the poll() system call to efficiently determine
// which sources are ready.
//
// LOG Messages:
// log_printf("BEGIN: server_check_sources()\n");             // at beginning of function
// log_printf("poll()'ing to check %d input sources\n",...);  // prior to poll() call
// log_printf("poll() completed with return value %d\n",...); // after poll() call
// log_printf("poll() interrupted by a signal\n");            // if poll interrupted by a signal
// log_printf("join_ready = %d\n",...);                       // whether join queue has data
// log_printf("client %d '%s' data_ready = %d\n",...)         // whether client has data ready
// log_printf("END: server_check_sources()\n");               // at end of function

int server_join_ready(server_t *server){
  return server->join_ready;
}
// Return the join_ready flag from the server which indicates whether
// a call to server_handle_join() is safe.

int server_handle_join(server_t *server){
  if(!server_join_ready(server)){
    perror("Not true");
    exit(-1);
  }
  log_printf("BEGIN: server_handle_join()\n");               // at beginnning of function
  join_t join;//send join
    memset(&join,0,sizeof(join_t));
  int bytes=read(server->join_fd, &join, sizeof(join_t));//read join message
    check_fail(bytes==-1,1,"Can't read\n");
  log_printf("join request for new client '%s'\n",join.name);      // reports name of new client
  server_add_client(server,&join);
  mesg_t msg;//send join message
  memset(&msg, 0, sizeof(mesg_t));
  msg.kind=BL_JOINED;
  strncpy(msg.name, join.name,MAXNAME);
  server_broadcast(server, &msg);//broadcast to all client
  server->join_ready=0;
    dbg_printf("set the servers join_ready flag to 0\n");
  log_printf("END: server_handle_join()\n");                 // at end of function
  return 0;

}
// Call this function only if server_join_ready() returns true. Read a
// join request and add the new client to the server. After finishing,
// set the servers join_ready flag to 0.
//
// LOG Messages:
// log_printf("BEGIN: server_handle_join()\n");               // at beginnning of function
// log_printf("join request for new client '%s'\n",...);      // reports name of new client
// log_printf("END: server_handle_join()\n");                 // at end of function

int server_client_ready(server_t *server, int idx){
  return server_get_client(server,idx)->data_ready;
}
// Return the data_ready field of the given client which indicates
// whether the client has data ready to be read from it.

int server_handle_client(server_t *server, int idx){
  if(server_client_ready(server,idx)==0){
    perror("Not ready");
    exit(-1);
  }
  log_printf("BEGIN: server_handle_client()\n");           // at beginning of function
  mesg_t msg;
    memset(&msg,0,sizeof(mesg_t));
  int byte=read(server_get_client(server,idx)->to_server_fd,&msg,sizeof(mesg_t));
    check_fail(byte==-1,1,"Can't read\n");
  if(msg.kind==BL_DEPARTED){//depature message
    
    server_remove_client(server,idx);
    server_broadcast(server, &msg);
    log_printf("client %d '%s' DEPARTED\n", idx,msg.name);                 // indicates client departed
  }
  else if(msg.kind==BL_MESG){//general message
    
    server_broadcast(server, &msg);
    server_get_client(server, idx)->data_ready = 0;
      log_printf("client %d '%s' MESSAGE '%s'\n", idx,msg.name,msg.body);            // indicates client message

  }
  else if(msg.kind==BL_PING){//ping message
    server_get_client(server,idx)->last_contact_time=server->time_sec;//Ping
    // responses should only change the last_contact_time below.
    //server_ping_clients(server);

  }
  log_printf("END: server_handle_client()\n");             // at end of function
  return 0;

}
// Process a message from the specified client. This function should
// only be called if server_client_ready() returns true. Read a
// message from to_server_fd and analyze the message kind. Departure
// and Message types should be broadcast to all other clients.  Ping
// responses should only change the last_contact_time below. Behavior
// for other message types is not specified. Clear the client's
// data_ready flag so it has value 0.
//
// ADVANCED: Update the last_contact_time of the client to the current
// server time_sec.
//
// LOG Messages:
// log_printf("BEGIN: server_handle_client()\n");           // at beginning of function
// log_printf("client %d '%s' DEPARTED\n",                  // indicates client departed
// log_printf("client %d '%s' MESSAGE '%s'\n",              // indicates client message
// log_printf("END: server_handle_client()\n");             // at end of function

void server_tick(server_t *server){
  server->time_sec++;
}
// ADVANCED: Increment the time for the server

void server_ping_clients(server_t *server){
 mesg_t msg;
    memset(&msg,0,sizeof(mesg_t));
 msg.kind=BL_PING;
 server_broadcast(server, &msg);
}
// ADVANCED: Ping all clients in the server by broadcasting a ping.

void server_remove_disconnected(server_t *server, int disconnect_secs){
  for(int i=0;i<server->n_clients;i++){
    if(server_get_client(server, i)->last_contact_time>=(disconnect_secs+server->time_sec)){
      server_remove_client(server,i);
      mesg_t m;
        memset(&m,0,sizeof(mesg_t));
      strncpy(m.name,server_get_client(server, i)->name,MAXNAME);
      m.kind=BL_DISCONNECTED;
      server_broadcast(server, &m);
      i-=1;//loop indexing as clients may be removed during the loop
    }
  }
}
// ADVANCED: Check all clients to see if they have contacted the
// server recently. Any client with a last_contact_time field equal to
// or greater than the parameter disconnect_secs should be
// removed. Broadcast that the client was disconnected to remaining
// clients.  Process clients from lowest to highest and take care of
// loop indexing as clients may be removed during the loop
// necessitating index adjustments.

void server_write_who(server_t *server){


}
// ADVANCED: Write the current set of clients logged into the server
// to the BEGINNING the log_fd. Ensure that the write is protected by
// locking the semaphore associated with the log file. Since it may
// take some time to complete this operation (acquire semaphore then
// write) it should likely be done in its own thread to preven the
// main server operations from stalling.  For threaded I/O, consider
// using the pwrite() function to write to a specific location in an
// open file descriptor which will not alter the position of log_fd so
// that appends continue to write to the end of the file.

void server_log_message(server_t *server, mesg_t *mesg){
  write(server->log_fd,mesg,sizeof(mesg_t));
}
// ADVANCED: Write the given message to the end of log file associated
// with the server.
