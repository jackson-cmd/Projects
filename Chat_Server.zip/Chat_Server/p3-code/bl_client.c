#include "blather.h"

// read name of server and name of user from command line args
// create to-server and to-client FIFOs
// write a join_t request to the server FIFO
// start a user thread to read inpu
// start a server thread to listen to the server
// wait for threads to return
// restore standard terminal output
//
// user thread{
//   repeat:
//     read input using simpio
//     when a line is ready
//     create a mesg_t with the line and write it to the to-server FIFO
//   until end of input
//   write a DEPARTED mesg_t into to-server
//   cancel the server thread
//
// server thread{
//   repeat:
//     read a mesg_t from to-client FIFO
//     print appropriate response to terminal with simpio
//   until a SHUTDOWN mesg_t is read
//   cancel the user thread

#define EXTRA 16
//extra for the file name
void *user_thread();
void *server_thread();

simpio_t simpio_actual;
simpio_t *simpio = &simpio_actual;

pthread_t user_t;
pthread_t serv_t;//server thread

join_t joint;



int main(int argc, char *argv[]){
  char client[MAXNAME+EXTRA];//client fifo
  char server[MAXNAME+EXTRA];//
  char serverfifo[MAXNAME+EXTRA];

  snprintf(client, MAXNAME+13,  "%d.client.fifo", getpid()); //server to client fifo
  snprintf(server, MAXNAME+13,  "%d.server.fifo", getpid()); //server from client fifo

  snprintf(serverfifo, MAXNAME+6, "%s.fifo", argv[1]);
  mkfifo(client,DEFAULT_PERMS);//make to client fifo
  mkfifo(server,DEFAULT_PERMS);//make to server fifo
  memset(&joint,0,sizeof(join_t));
  strcpy(joint.to_client_fname,client);
  strcpy(joint.to_server_fname,server);
  strncpy(joint.name,argv[2],MAXPATH);
  int fd=open(serverfifo,O_WRONLY,DEFAULT_PERMS);
    check_fail(fd==-1,1,"Can't open fifo\n");
  write(fd, &joint,sizeof(join_t));

  char prompt[MAXPATH+2];//extra 2 for >>
  sprintf(prompt, "%s>>",joint.name); // create a prompt string
  simpio_set_prompt(simpio, prompt);         // set the prompt
  simpio_reset(simpio);                      // initialize io
  simpio_noncanonical_terminal_mode();       // set the terminal into a compatible mode

  pthread_create(&user_t,   NULL, user_thread,   NULL);     // start user thread to read input
  pthread_create(&serv_t, NULL, server_thread, NULL);
  pthread_join(user_t, NULL);//wait
  pthread_join(serv_t, NULL);

  simpio_reset_terminal_mode();//reset terminal
  printf("\n");                 // newline just to make returning to the terminal prettier
  return 0;

}

// User thread to manage user input
void *user_thread(){
  //////
int fd1=open(joint.to_server_fname,O_WRONLY,DEFAULT_PERMS);
	while(!simpio->end_of_input){
	  simpio_reset(simpio);
    iprintf(simpio, "");                                          // print prompt
    while(!simpio->line_ready && !simpio->end_of_input){          // read until line is complete
	    simpio_get_char(simpio);
    }
    if(simpio->line_ready){
      mesg_t m;//send message
      memset(&m,0,sizeof(mesg_t));
      m.kind=BL_MESG;
      strcpy(m.name,joint.name);
      strcpy(m.body,simpio->buf);
//	int fd1=open(joint.to_server_fname,O_WRONLY,DEFAULT_PERMS);
      write(fd1,&m,sizeof(mesg_t));
    }
  }
  mesg_t de;//send depature message
    memset(&de,0,sizeof(mesg_t));
  de.kind=BL_DEPARTED;
  strcpy(de.name,joint.name);
  write(fd1,&de,sizeof(mesg_t));
  pthread_cancel(serv_t); // kill the background thread
  return NULL;
}

// server thread to listen to the info from the server.
void *server_thread(){
  int fd2=open(joint.to_client_fname,O_RDONLY,DEFAULT_PERMS);
  while(1){
    mesg_t to;//to-client
     memset(&to,0,sizeof(mesg_t));
    if (read(fd2, &to, sizeof(mesg_t)) > 0){//read success
        if (to.kind == BL_MESG){
          iprintf(simpio, "[%s] : %s\n", to.name, to.body);
        }
        else if (to.kind == BL_JOINED){
          iprintf(simpio, "-- %s JOINED --\n", to.name);
        }
        else if (to.kind == BL_DEPARTED){
          iprintf(simpio, "-- %s DEPARTED --\n", to.name);
        }
        else if (to.kind == BL_SHUTDOWN){
          iprintf(simpio, "!!! server is shutting down !!!\n");
          break;
        }
        else if (to.kind == BL_DISCONNECTED){
          iprintf(simpio, "-- %s DISCONNECTED --\n", to.name);
        }
        else if (to.kind == BL_PING){
          //send bl to server
        }

        else{//no kind, return null
          return NULL;
      }
    }
  }
  pthread_cancel(user_t);
  return NULL;
}
